"""CSV export/import for devices, ports, cables, sites, and the
enabled-roles/enabled-speeds/enabled-reports picker settings, plus the
Backup/Restore zip bundle built on top of all seven.

The CSVs reference devices/ports by name rather than database id.

Replace semantics: replacing devices also replaces ports, cables, and
LAGs. Replacing ports also replaces cables and clears LAG membership.
Replacing cables only replaces cables. Replacing sites, roles, speeds,
or reports replaces that whole list without touching any device/port's
own stored value. A Restore applies devices/ports/cables (in that order)
and then sites/roles/speeds/reports, for whichever of those it finds in
the zip.
"""

import csv
import io
import json
import zipfile
from datetime import datetime, timezone

from . import crud, db

# A devices CSV is detected by DEVICE_CORE_COLUMNS; DEVICE_MAP_COLUMNS are optional.
DEVICE_CORE_COLUMNS = ["name", "role", "model", "site", "notes", "poe_required"]
DEVICE_MAP_COLUMNS = ["pos_x", "pos_y", "ports_per_row", "show_on_map", "port_layout_mode"]
DEVICE_COLUMNS = DEVICE_CORE_COLUMNS + DEVICE_MAP_COLUMNS
# grid_row/grid_col apply only when port_layout_mode is 'custom'. mac_address
# is optional on import/export.
PORT_COLUMNS = ["device_name", "port_name", "speed", "vlans", "poe_supply", "pair_with",
                "wireless_link", "uplink_for", "lag", "grid_row", "grid_col", "mac_address"]
CABLE_COLUMNS = ["device_a", "port_a", "device_b", "port_b", "label"]
SITE_COLUMNS = ["name"]
ROLE_COLUMNS = ["role"]      # one row per currently-enabled role
SPEED_COLUMNS = ["speed"]    # one row per currently-enabled speed
REPORT_COLUMNS = ["report"]  # one row per currently-enabled report

# Used to auto-detect which type an uploaded CSV is, from its header row.
_SCHEMAS = {
    "devices": set(DEVICE_CORE_COLUMNS),
    "ports": {"device_name", "port_name", "speed", "vlans", "poe_supply", "pair_with"},
    "cables": set(CABLE_COLUMNS),
    "sites": set(SITE_COLUMNS),
    "roles": set(ROLE_COLUMNS),
    "speeds": set(SPEED_COLUMNS),
    "reports": set(REPORT_COLUMNS),
}


def _yesno(v) -> bool:
    return str(v or "").strip().lower() in ("yes", "y", "true", "1")


def _float_cell(v):
    v = (v or "").strip()
    try:
        return float(v) if v else None
    except ValueError:
        return None


def _int_cell(v):
    v = (v or "").strip()
    try:
        return int(v) if v else None
    except ValueError:
        return None


def _bool_cell(v) -> str:
    return "yes" if v else "no"


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

def export_csv(conn, kind: str) -> bytes:
    if kind == "devices":
        return _export_devices(conn)
    if kind == "ports":
        return _export_ports(conn)
    if kind == "cables":
        return _export_cables(conn)
    if kind == "sites":
        return _export_sites(conn)
    if kind == "roles":
        return _export_roles(conn)
    if kind == "speeds":
        return _export_speeds(conn)
    if kind == "reports":
        return _export_reports(conn)
    raise ValueError(f"unknown export kind: {kind!r}")


def _export_devices(conn) -> bytes:
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(DEVICE_COLUMNS)
    for d in crud.list_devices(conn):
        w.writerow([
            d["name"], d["role"], d["model"], d["site"], d["notes"], _bool_cell(d["poe_required"]),
            "" if d["pos_x"] is None else d["pos_x"],
            "" if d["pos_y"] is None else d["pos_y"],
            "" if d["ports_per_row"] is None else d["ports_per_row"],
            _bool_cell(d["show_on_map"]),
            d["port_layout_mode"],
        ])
    return out.getvalue().encode("utf-8")


def _export_ports(conn) -> bytes:
    devices = crud.list_devices(conn)
    device_by_id = {d["id"]: d for d in devices}
    all_ports = []
    port_lookup = {}  # port_id -> (device_name, port_name)
    for d in devices:
        for p in crud.list_ports(conn, d["id"]):
            p["device_name"] = d["name"]
            all_ports.append(p)
            port_lookup[p["id"]] = (d["name"], p["name"])

    # port_id -> name of the AP Group / Virtual Switch it's an uplink for
    uplink_for = {
        row["port_id"]: row["vs_name"]
        for row in conn.execute(
            "SELECT u.port_id, d.name AS vs_name FROM virtual_switch_uplinks u "
            "JOIN devices d ON d.id = u.virtual_switch_id"
        ).fetchall()
    }
    # port_id -> name of the LAG (on the same device) it's a member of
    lag_name = {
        row["id"]: row["lag_name"]
        for row in conn.execute(
            "SELECT ports.id, lags.name AS lag_name FROM ports JOIN lags ON lags.id = ports.lag_id"
        ).fetchall()
    }

    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(PORT_COLUMNS)
    for p in all_ports:
        pair_with = ""
        if p["pair_port_id"] and p["pair_port_id"] in port_lookup:
            pair_with = port_lookup[p["pair_port_id"]][1]
        wireless_link = ""
        if p["virtual_switch_id"] and p["virtual_switch_id"] in device_by_id:
            wireless_link = device_by_id[p["virtual_switch_id"]]["name"]
        w.writerow([p["device_name"], p["name"], p["speed"], p["vlans"], _bool_cell(p["poe_supply"]),
                    pair_with, wireless_link, uplink_for.get(p["id"], ""), lag_name.get(p["id"], ""),
                    "" if p["grid_row"] is None else p["grid_row"],
                    "" if p["grid_col"] is None else p["grid_col"],
                    p["mac_address"] or ""])
    return out.getvalue().encode("utf-8")


def _export_cables(conn) -> bytes:
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(CABLE_COLUMNS)
    for c in crud.list_cables(conn):
        w.writerow([c["a_device_name"], c["a_port_name"], c["b_device_name"], c["b_port_name"], c["label"]])
    return out.getvalue().encode("utf-8")


def _export_sites(conn) -> bytes:
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(SITE_COLUMNS)
    for s in crud.list_sites(conn):
        w.writerow([s["name"]])
    return out.getvalue().encode("utf-8")


def _export_roles(conn) -> bytes:
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(ROLE_COLUMNS)
    for role in crud.get_enabled_roles(conn):
        w.writerow([role])
    return out.getvalue().encode("utf-8")


def _export_speeds(conn) -> bytes:
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(SPEED_COLUMNS)
    for speed in crud.get_enabled_speeds(conn):
        w.writerow([speed])
    return out.getvalue().encode("utf-8")


def _export_reports(conn) -> bytes:
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(REPORT_COLUMNS)
    for report in crud.get_enabled_reports(conn):
        w.writerow([report])
    return out.getvalue().encode("utf-8")


# ---------------------------------------------------------------------------
# Import
# ---------------------------------------------------------------------------

_EXACT_MATCH_KINDS = {"sites", "roles", "speeds", "reports"}  # single-column kinds


def _detect_kind(header_fields):
    header_set = {f.strip() for f in (header_fields or []) if f and f.strip()}
    for kind, schema in _SCHEMAS.items():
        if kind in _EXACT_MATCH_KINDS:
            # A lone "name"/"role"/"speed"/"report" column is ambiguous as a
            # *subset* check -- it'd also match any header that happens to
            # carry that column alongside unrelated ones. Require the header
            # to be exactly that one column.
            if schema == header_set:
                return kind
        elif schema <= header_set:  # every required column present; extra columns tolerated
            return kind
    return None


def _raise_validation(errors):
    preview = "; ".join(errors[:8])
    more = f" (+{len(errors) - 8} more)" if len(errors) > 8 else ""
    raise crud.ConflictError(f"import validation failed: {preview}{more}")


def import_csv(conn, data: bytes) -> dict:
    """Validates the CSV before touching the database. Detects
    devices/ports/cables/sites/roles/speeds/reports from the header row
    and replaces only that one."""
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise crud.ConflictError("that doesn't look like a valid CSV (text) file")

    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        raise crud.ConflictError("the CSV file is empty")

    kind = _detect_kind(reader.fieldnames)
    if kind is None:
        raise crud.ConflictError(
            "unrecognized CSV columns -- expected a devices, ports, cables, sites, roles, "
            "speeds, or reports export from LinkLedger (see Help for the exact column names)"
        )
    rows = list(reader)

    if kind == "devices":
        _import_devices(conn, rows)
    elif kind == "ports":
        _import_ports(conn, rows)
    elif kind == "cables":
        _import_cables(conn, rows)
    elif kind == "sites":
        _import_sites(conn, rows)
    elif kind == "roles":
        _import_roles(conn, rows)
    elif kind == "speeds":
        _import_speeds(conn, rows)
    else:
        _import_reports(conn, rows)

    return {"type": kind, "count": len(rows)}


def _import_devices(conn, rows):
    errors = []
    names = set()
    for i, row in enumerate(rows, start=2):
        name = (row.get("name") or "").strip()
        if not name:
            errors.append(f"row {i}: missing name")
            continue
        if name in names:
            errors.append(f"row {i}: duplicate device name '{name}'")
        names.add(name)
    if errors:
        _raise_validation(errors)

    conn.execute("DELETE FROM cables")
    conn.execute("DELETE FROM ports")
    conn.execute("DELETE FROM devices")
    for row in rows:
        role = (row.get("role") or "").strip()
        # Falls back to the role-based default when show_on_map is absent.
        show_on_map_cell = row.get("show_on_map")
        show_on_map = (_yesno(show_on_map_cell) if show_on_map_cell not in (None, "")
                       else role not in db.MAP_HIDDEN_BY_DEFAULT_ROLES)
        # Defaults to 'auto' when absent or unrecognized.
        port_layout_mode = (row.get("port_layout_mode") or "").strip().lower()
        if port_layout_mode not in ("auto", "custom"):
            port_layout_mode = "auto"
        conn.execute(
            "INSERT INTO devices (name, role, model, site, notes, poe_required, pos_x, pos_y, "
            "ports_per_row, show_on_map, port_layout_mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (row["name"].strip(), role, (row.get("model") or "").strip(),
             (row.get("site") or "").strip(), (row.get("notes") or "").strip(),
             int(_yesno(row.get("poe_required"))),
             _float_cell(row.get("pos_x")), _float_cell(row.get("pos_y")),
             _int_cell(row.get("ports_per_row")), int(show_on_map), port_layout_mode),
        )


def _import_ports(conn, rows):
    device_roles = {row["name"]: row["role"] for row in conn.execute("SELECT name, role FROM devices").fetchall()}
    device_names = set(device_roles)

    errors = []
    port_keys = set()
    for i, row in enumerate(rows, start=2):
        dname = (row.get("device_name") or "").strip()
        pname = (row.get("port_name") or "").strip()
        if not dname or not pname:
            errors.append(f"row {i}: missing device_name or port_name")
            continue
        if dname not in device_names:
            errors.append(f"row {i}: device '{dname}' not found -- add it first (or import a devices CSV)")
            continue
        key = (dname, pname)
        if key in port_keys:
            errors.append(f"row {i}: duplicate port '{pname}' on device '{dname}'")
        port_keys.add(key)
        speed = (row.get("speed") or "").strip()
        if speed and speed not in crud.SPEED_MBPS:
            errors.append(f"row {i}: unrecognized speed '{speed}'")

    mac_cells = {}  # normalized MAC -> first row number that used it
    for i, row in enumerate(rows, start=2):
        mac_raw = (row.get("mac_address") or "").strip()
        if not mac_raw:
            continue
        try:
            mac = crud.normalize_mac(mac_raw)
        except crud.ConflictError as e:
            errors.append(f"row {i}: {e}")
            continue
        if mac in mac_cells:
            errors.append(f"row {i}: MAC address {mac} is already used on row {mac_cells[mac]}")
        else:
            mac_cells[mac] = i

    pair_edges = {}  # (device_name, port_name) -> the port name it's paired with
    for i, row in enumerate(rows, start=2):
        dname = (row.get("device_name") or "").strip()
        pname = (row.get("port_name") or "").strip()
        pair_with = (row.get("pair_with") or "").strip()
        wireless_link = (row.get("wireless_link") or "").strip()
        uplink_for = (row.get("uplink_for") or "").strip()
        if pair_with and (dname, pair_with) not in port_keys:
            errors.append(f"row {i}: pair_with '{pair_with}' not found on device '{dname}'")
        elif pair_with == pname:
            errors.append(f"row {i}: port '{pname}' can't be paired with itself")
        elif pair_with:
            key_a, key_b = (dname, pname), (dname, pair_with)
            if key_a in pair_edges and pair_edges[key_a] != pair_with:
                errors.append(f"row {i}: port '{pname}' is already paired with '{pair_edges[key_a]}' from another row")
            elif key_b in pair_edges and pair_edges[key_b] != pname:
                errors.append(f"row {i}: port '{pair_with}' is already paired with '{pair_edges[key_b]}' from another row")
            else:
                pair_edges[key_a] = pair_with
                pair_edges[key_b] = pname
        if wireless_link and pair_with:
            errors.append(f"row {i}: a port can't have both pair_with and wireless_link")
        for label, name in (("wireless_link", wireless_link), ("uplink_for", uplink_for)):
            if not name:
                continue
            if name not in device_roles:
                errors.append(f"row {i}: {label} '{name}' not found -- add it first (or import a devices CSV)")
            elif device_roles[name] not in crud.db.VIRTUAL_SWITCH_ROLES:
                errors.append(f"row {i}: {label} '{name}' isn't an AP Group or Virtual Switch device")

    if errors:
        _raise_validation(errors)

    # Replacing ports clears cables and LAGs; LAGs are repopulated below from the `lag` column.
    conn.execute("DELETE FROM cables")
    conn.execute("DELETE FROM ports")
    conn.execute("DELETE FROM lags")

    device_ids = {row["name"]: row["id"] for row in conn.execute("SELECT id, name FROM devices").fetchall()}
    port_ids = {}
    for row in rows:
        dname, pname = row["device_name"].strip(), row["port_name"].strip()
        mac_raw = (row.get("mac_address") or "").strip()
        mac = crud.normalize_mac(mac_raw) if mac_raw else None
        cur = conn.execute(
            "INSERT INTO ports (device_id, name, speed, vlans, poe_supply, grid_row, grid_col, mac_address) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (device_ids[dname], pname, (row.get("speed") or "").strip(), (row.get("vlans") or "").strip(),
             int(_yesno(row.get("poe_supply"))),
             _int_cell(row.get("grid_row")), _int_cell(row.get("grid_col")), mac),
        )
        port_ids[(dname, pname)] = cur.lastrowid

    for row in rows:
        pair_with = (row.get("pair_with") or "").strip()
        if not pair_with:
            continue
        dname, pname = row["device_name"].strip(), row["port_name"].strip()
        a, b = port_ids[(dname, pname)], port_ids[(dname, pair_with)]
        conn.execute("UPDATE ports SET pair_port_id = ? WHERE id = ?", (b, a))
        conn.execute("UPDATE ports SET pair_port_id = ? WHERE id = ? AND pair_port_id IS NULL", (a, b))

    for row in rows:
        wireless_link = (row.get("wireless_link") or "").strip()
        if not wireless_link:
            continue
        dname, pname = row["device_name"].strip(), row["port_name"].strip()
        conn.execute("UPDATE ports SET virtual_switch_id = ? WHERE id = ?",
                      (device_ids[wireless_link], port_ids[(dname, pname)]))

    for row in rows:
        uplink_for = (row.get("uplink_for") or "").strip()
        if not uplink_for:
            continue
        dname, pname = row["device_name"].strip(), row["port_name"].strip()
        conn.execute("INSERT INTO virtual_switch_uplinks (virtual_switch_id, port_id) VALUES (?, ?)",
                      (device_ids[uplink_for], port_ids[(dname, pname)]))

    # LAG membership -- a lag name is scoped to its device.
    lag_ids = {}  # (device_name, lag_name) -> lag_id
    for row in rows:
        lag_name = (row.get("lag") or "").strip()
        if not lag_name:
            continue
        dname, pname = row["device_name"].strip(), row["port_name"].strip()
        key = (dname, lag_name)
        if key not in lag_ids:
            cur = conn.execute("INSERT INTO lags (device_id, name) VALUES (?, ?)", (device_ids[dname], lag_name))
            lag_ids[key] = cur.lastrowid
        conn.execute("UPDATE ports SET lag_id = ? WHERE id = ?", (lag_ids[key], port_ids[(dname, pname)]))


def _import_cables(conn, rows):
    port_rows = conn.execute(
        "SELECT ports.id, ports.name AS port_name, devices.name AS device_name FROM ports "
        "JOIN devices ON devices.id = ports.device_id"
    ).fetchall()
    port_ids = {(r["device_name"], r["port_name"]): r["id"] for r in port_rows}

    errors = []
    for i, row in enumerate(rows, start=2):
        da, pa = (row.get("device_a") or "").strip(), (row.get("port_a") or "").strip()
        db_, pb = (row.get("device_b") or "").strip(), (row.get("port_b") or "").strip()
        if not all([da, pa, db_, pb]):
            errors.append(f"row {i}: missing device/port reference")
            continue
        if (da, pa) not in port_ids:
            errors.append(f"row {i}: port '{pa}' on device '{da}' not found")
        if (db_, pb) not in port_ids:
            errors.append(f"row {i}: port '{pb}' on device '{db_}' not found")
        if da == db_ and pa == pb:
            errors.append(f"row {i}: a port can't be cabled to itself")
    if errors:
        _raise_validation(errors)

    conn.execute("DELETE FROM cables")
    for row in rows:
        a = port_ids[(row["device_a"].strip(), row["port_a"].strip())]
        b = port_ids[(row["device_b"].strip(), row["port_b"].strip())]
        conn.execute(
            "INSERT INTO cables (port_a_id, port_b_id, label) VALUES (?, ?, ?)",
            (a, b, (row.get("label") or "").strip()),
        )


def _import_sites(conn, rows):
    """Replaces the whole managed Sites list."""
    errors = []
    names = set()
    for i, row in enumerate(rows, start=2):
        name = (row.get("name") or "").strip()
        if not name:
            errors.append(f"row {i}: missing name")
            continue
        if name in names:
            errors.append(f"row {i}: duplicate site '{name}'")
        names.add(name)
    if errors:
        _raise_validation(errors)

    conn.execute("DELETE FROM sites")
    for row in rows:
        conn.execute("INSERT INTO sites (name) VALUES (?)", (row["name"].strip(),))


def _import_roles(conn, rows):
    """Replaces the enabled-roles picker setting."""
    errors = []
    roles = []
    for i, row in enumerate(rows, start=2):
        role = (row.get("role") or "").strip()
        if not role:
            errors.append(f"row {i}: missing role")
            continue
        if role not in db.ROLES:
            errors.append(f"row {i}: unrecognized role '{role}'")
            continue
        roles.append(role)
    if errors:
        _raise_validation(errors)
    crud.set_enabled_roles(conn, roles)


def _import_speeds(conn, rows):
    """Replaces the enabled-speeds picker setting."""
    errors = []
    speeds = []
    for i, row in enumerate(rows, start=2):
        speed = (row.get("speed") or "").strip()
        if not speed:
            errors.append(f"row {i}: missing speed")
            continue
        if speed not in crud.SPEED_MBPS:
            errors.append(f"row {i}: unrecognized speed '{speed}'")
            continue
        speeds.append(speed)
    if errors:
        _raise_validation(errors)
    crud.set_enabled_speeds(conn, speeds)


def _import_reports(conn, rows):
    """Replaces the Reports-tab visibility setting."""
    errors = []
    reports = []
    for i, row in enumerate(rows, start=2):
        report = (row.get("report") or "").strip()
        if not report:
            errors.append(f"row {i}: missing report")
            continue
        if report not in crud.REPORT_KEYS:
            errors.append(f"row {i}: unrecognized report '{report}'")
            continue
        reports.append(report)
    if errors:
        _raise_validation(errors)
    crud.set_enabled_reports(conn, reports)


# ---------------------------------------------------------------------------
# Backup / Restore -- a single .zip bundling all seven CSVs plus a small
# metadata file.
# ---------------------------------------------------------------------------

BACKUP_INFO_FILENAME = "backup-info.json"


def build_backup_zip(conn, version: str) -> tuple[bytes, str]:
    """Builds the Backup .zip: devices.csv, ports.csv, cables.csv, sites.csv,
    roles.csv, speeds.csv, reports.csv, and a backup-info.json with the
    creation time and LinkLedger version. Returns (zip_bytes, created_at)."""
    created_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    info = {"linkledger_version": version, "created_at": created_at}

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("devices.csv", export_csv(conn, "devices"))
        zf.writestr("ports.csv", export_csv(conn, "ports"))
        zf.writestr("cables.csv", export_csv(conn, "cables"))
        zf.writestr("sites.csv", export_csv(conn, "sites"))
        zf.writestr("roles.csv", export_csv(conn, "roles"))
        zf.writestr("speeds.csv", export_csv(conn, "speeds"))
        zf.writestr("reports.csv", export_csv(conn, "reports"))
        zf.writestr(BACKUP_INFO_FILENAME, json.dumps(info, indent=2) + "\n")
    return buf.getvalue(), created_at


def restore_backup_zip(conn, data: bytes) -> dict:
    """Restores a Backup .zip, or any zip containing one or more of
    devices.csv/ports.csv/cables.csv/sites.csv/roles.csv/speeds.csv/
    reports.csv (detected by column header, not filename). Applies
    devices/ports/cables in that order, then sites/roles/speeds/reports.
    Non-CSV members and unrecognized CSVs are ignored. Raises ConflictError
    if nothing usable is found or any CSV fails validation."""
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise crud.ConflictError("that doesn't look like a valid backup .zip file")

    detected = {}  # kind -> csv bytes; last match wins if a kind appears twice
    for name in zf.namelist():
        if not name.lower().endswith(".csv"):
            continue
        content = zf.read(name)
        try:
            text = content.decode("utf-8-sig")
        except UnicodeDecodeError:
            continue
        reader = csv.DictReader(io.StringIO(text))
        kind = _detect_kind(reader.fieldnames) if reader.fieldnames else None
        if kind:
            detected[kind] = content

    if not detected:
        raise crud.ConflictError(
            "no devices/ports/cables/sites/roles/speeds/reports CSV found inside the .zip -- "
            "expected a LinkLedger backup"
        )

    summary = {}
    for kind in ("devices", "ports", "cables", "sites", "roles", "speeds", "reports"):
        if kind in detected:
            result = import_csv(conn, detected[kind])
            summary[result["type"]] = result["count"]
    return summary
